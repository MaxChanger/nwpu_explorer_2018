#include <ros/ros.h>
#include <std_msgs/Float32.h>
#include <explorer_msgs/explorer_low_level_data.h>

void co2MsgSub(const explorer_msgs::explorer_low_level_dataConstPtr &ptr){
  float data_01 = ptr->can_serial_data_1 ;


}
int main(int argc, char **argv)
{
  ros::init(argc, argv, "frame_co2");
  ros::NodeHandle nh;
  ros::Subscriber frame_co2_Sub;


  //frame_co2_Sub = nh.subscribe("/explorer_serial_data/19" ,10, &co2MsgSub,this);
  ROS_INFO("Hello world!");
  ros::spin();
}
