#ifndef FORM_CO2_H
#define FORM_CO2_H
//#include <QApplication>
//#include <QWidget>
#include <ros/ros.h>
#include <explorer_msgs/explorer_low_level_data.h>

namespace Ui {
class Form_co2;
}

class Form_co2 : public QWidget
{
  Q_OBJECT

public:
  explicit Form_co2(QWidget *parent = 0);
  ~Form_co2();
  void co2MsgSub(const explorer_msgs::explorer_low_level_dataConstPtr &ptr) ;
  ros::Subscriber frame_co2_Sub;
private:
  Ui::Form_co2 *ui;
};

#endif // FORM_CO2_H
