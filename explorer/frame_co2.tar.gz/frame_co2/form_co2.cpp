#include "form_co2.h"
#include "ui_form_co2.h"
#include <ros/ros.h>

Form_co2::Form_co2(QWidget *parent) :
  QWidget(parent),
  ui(new Ui::Form_co2)
{
  frame_co2_Sub = nh.subscribe("/explorer_serial_data/19" ,10, &co2MsgSub,this);
  ui->setupUi(this);
}

Form_co2::~Form_co2()
{
  delete ui;
}
void co2MsgSub(const explorer_msgs::explorer_low_level_dataConstPtr &ptr){
  ui->co2_label->setText(ptr->can_serial_data_1);
}
