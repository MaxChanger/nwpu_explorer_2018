#include <ros/ros.h>  
#include <actionlib/server/simple_action_server.h>  
#include <control_msgs/FollowJointTrajectoryAction.h>  
#include <trajectory_msgs/JointTrajectory.h>  
#include <std_msgs/Float64.h>  
#include <iostream>  
#include <vector>  
#include <string>  
#include <sensor_msgs/JointState.h>  
#include <map>  
#include <explorer_msgs/explorer_moveit_values.h> 
using namespace std ;  
typedef actionlib::SimpleActionServer<control_msgs::FollowJointTrajectoryAction> Server;  //用于轨迹的server
  
class RobotTrajectoryFollower  
{  
protected:  
  
  ros::NodeHandle nh_;  
  // NodeHandle instance must be created before this line. Otherwise strange error may occur.  
  //actionlib::SimpleActionServer<control_msgs::FollowJointTrajectoryAction> as_;  
  std::string action_name_;  
  
  ros::Publisher joint_pub ; //向rviz发布 
  ros::Publisher joint_vales_pub ; //向下位机发送 
  sensor_msgs::JointState joint_state;  //节点的状态
  explorer_msgs::explorer_moveit_values joint_values1,joint_values2;//向下发送的joint_values,需要两个值，向下传输的是两个值相减
  control_msgs::FollowJointTrajectoryResult result_;  
  control_msgs::FollowJointTrajectoryActionGoal agoal_;  
  control_msgs::FollowJointTrajectoryActionFeedback afeedback_;  
  control_msgs::FollowJointTrajectoryFeedback feedback_;
  std::vector<double> joint_posi1;
  int arm_name[6];
public:  
  map< string, int > MotoName_Id;  
  RobotTrajectoryFollower(std::string name) :  
    nh_("~"),  
    as_(nh_, name,boost::bind(&RobotTrajectoryFollower::goalCB, this, _1),  false),  
    action_name_(name)  
  {  
    
    
    int m =0;
    for(;m<6;m++){
      joint_values1.names.push_back(m+1);
      joint_values2.names.push_back(m+1);
      joint_values1.values.push_back(0);
      joint_values2.values.push_back(0);
    }

    ROS_INFO("GET THE NAME");             //grroup无法更新全部的消息
    //joint_pub = nh_.advertise<sensor_msgs::JointState>("/move_group/fake_controller_joint_states", 10);  //向rviz中发布消息来更新模型的状态

    //joint_pub = nh_.advertise<sensor_msgs::JointState>("joint_states", 1);
    joint_vales_pub = nh_.advertise<explorer_msgs::explorer_moveit_values>("explorer_moveit_joint", 1);  //向下传递
  
    //Register callback functions:  
    //as_.registerGoalCallback(boost::bind(&RobotTrajectoryFollower::goalCB, this,_1));  
    as_.registerPreemptCallback(boost::bind(&RobotTrajectoryFollower::preemptCB, this));  
  
    as_.start();  
  }  
  
  ~RobotTrajectoryFollower(void)//Destructor  
  {  
  }  
// 发送至rviz中的 
  void setJointStateName(std::vector<std::string> joint_names){  
    joint_state.name.resize(joint_names.size());  
    joint_state.name.assign(joint_names.begin(), joint_names.end());  
    //joint_state.name[0] ="arm_1_to_arm_base";  
    //std::vector<std::string>::iterator it;  
    //for ( it = joint_state.name.begin(); it != joint_state.name.end(); it++){  
    //  cout <<(*it) <<endl;  
    //}  
    //cout <<endl ;  
  }  
  void setJointStatePosition(std::vector<double> joint_posi){  
    joint_state.position.resize(joint_posi.size());
    int i= 0;
    for(i= 0;i <6; i++){
    joint_state.position[i] = joint_posi[i];
    }

    //joint_state.position[0] = base_arm;  
    //std::vector<double>::iterator it;  
    //for ( it = joint_state.position.begin(); it != joint_state.position.end(); it++){  
    //  cout <<(*it) <<endl;  
    //}  
    //cout <<endl ;  
  }  
  void publishJointState(){  
    joint_state.header.stamp = ros::Time::now();  
    joint_pub.publish(joint_state);  
  }  
 //-------------------------------------

  //向下发送可以直接发送至arm_controller中
  //需要修改
  //此处用于将explorer_msgs::explorer_moveit_values类型额消息发送下去
  void joint_states_pub(std::vector<double> joint_posi){ 
    
    int i=0;

    /*for ( it = joint_posi.begin(); it != joint_posi.end(); it++,i++){  
      joint_values1.names[i]=ids[i]; //将需要发送的消息存入 这个数字对应一个名字,自己定义的是一个string 而现在这个传入的是一个数字
      joint_values1.values[i]=(*it);
      cout<< i<<endl;
    }
    cout <<"the number of the joint——posi"<<i <<endl;
    joint_vales_pub.publish(joint_values1); */
    for(i= 0;i<6;i++){
      joint_values1.values[i] = (float) joint_posi[i] - joint_values2.values[i];
      joint_values2.values[i] = joint_posi[i];
    }
    joint_vales_pub.publish(joint_values1);
  } 



  void goalCB(const control_msgs::FollowJointTrajectoryGoalConstPtr msg)  
  {  
    std::vector<std::string> joint_names=(*msg).trajectory.joint_names;  
    setJointStateName( joint_names);  

     //ids [joint_names.size()]; // 指得是id
    //for ( it = joint_names.begin(); it != joint_names.end(); it++,i++){  
      //ids[i]=MotoName_Id[(*it)];  
      //cout <<MotoName_Id[(*it)] <<endl; //将对应id放进去
      
    //}  
    //goal=(*msg);goal.trajectory.points;//c++ how to use this style??  
  
    std::vector<trajectory_msgs::JointTrajectoryPoint> points = (*msg).trajectory.points;//轨迹上的位置  
    std::vector<trajectory_msgs::JointTrajectoryPoint>::iterator pointsit;
    ros::Rate rate(10);//10hz  如何更改发出的速度值
    //size_t t=points.size();      
    for ( pointsit = points.begin(); pointsit != points.end(); pointsit++){   
      joint_states_pub((*pointsit).positions);
      int m = 0;
      //wait  
      rate.sleep();
      //then update joinstates an publish  
      setJointStatePosition((*pointsit).positions); 
      publishJointState(); 
      //feedback_.  
      //as_.publishFeedback(feedback_);      
    } 
    //传入的应该是全部节点的值
    //而现在传入的可能是一个值
    // accept the new goal  
    //as_.acceptNewGoal();  
    if(as_.isActive())as_.setSucceeded(); //如果收到消息，就默认是到达了指定的位置 
  }  
  
  void preemptCB()  
  {  
    ROS_INFO("%s: Preempted", action_name_.c_str());  
  
    if(as_.isActive()){  
        as_.setPreempted();  
    }  
  } 
  Server as_  ;   
};  
  
int main(int argc, char** argv)  
{  
  
  ros::init(argc, argv, "explorer_moveit_listener"); // Action client not connected: 
  RobotTrajectoryFollower RobotTrajectoryFollower("/explorer_arm_controllers/follow_joint_trajectory");   
  ROS_INFO("------------- joint controller is running .");  
  ros::spin();  
  return 0;   
}


/*
#include <ros/ros.h>
#include <std_msgs/Float32.h>
#include <actionlib/server/simple_action_server.h>
#include <actionlib_tutorials/AveragingAction.h>

class AveragingAction
{
public:
    
  AveragingAction(std::string name) : 
    as_(nh_, name, false),
    action_name_(name)
  {
    //register the goal and feeback callbacks
    as_.registerGoalCallback(boost::bind(&AveragingAction::goalCB, this));//初始化
    as_.registerPreemptCallback(boost::bind(&AveragingAction::preemptCB, this));//

    //subscribe to the data topic of interest
    sub_ = nh_.subscribe("/random_number", 1, &AveragingAction::analysisCB, this);
    as_.start();
  }

  ~AveragingAction(void)
  {
  }

  void goalCB()
  {
    // reset helper variables
    data_count_ = 0;
    sum_ = 0;
    sum_sq_ = 0;
    // accept the new goal
    goal_ = as_.acceptNewGoal()->samples;
  }

  void preemptCB()
  {
    ROS_INFO("%s: Preempted", action_name_.c_str());
    // set the action state to preempted
    as_.setPreempted();
  }

  void analysisCB(const std_msgs::Float32::ConstPtr& msg)
  {
    // make sure that the action hasn't been canceled
    if (!as_.isActive())
      return;
    
    data_count_++;
    feedback_.sample = data_count_;
    feedback_.data = msg->data;
    //compute the std_dev and mean of the data 
    sum_ += msg->data;
    feedback_.mean = sum_ / data_count_;
    sum_sq_ += pow(msg->data, 2);
    feedback_.std_dev = sqrt(fabs((sum_sq_/data_count_) - pow(feedback_.mean, 2)));
    as_.publishFeedback(feedback_);

    if(data_count_ > goal_) 
    {
      result_.mean = feedback_.mean;
      result_.std_dev = feedback_.std_dev;

      if(result_.mean < 5.0)
      {
        ROS_INFO("%s: Aborted", action_name_.c_str());
        //set the action state to aborted
        as_.setAborted(result_);
      }
      else 
      {
        ROS_INFO("%s: Succeeded", action_name_.c_str());
        // set the action state to succeeded
        as_.setSucceeded(result_);
      }
    } 
  }

protected:
    
  ros::NodeHandle nh_;
  actionlib::SimpleActionServer<actionlib_tutorials::AveragingAction> as_;
  std::string action_name_;
  int data_count_, goal_;
  float sum_, sum_sq_;
  actionlib_tutorials::AveragingFeedback feedback_;
  actionlib_tutorials::AveragingResult result_;
  ros::Subscriber sub_;
};

int main(int argc, char** argv)
{
  ros::init(argc, argv, "averaging");

  AveragingAction averaging(ros::this_node::getName());
  ros::spin();

  return 0;
}

*/