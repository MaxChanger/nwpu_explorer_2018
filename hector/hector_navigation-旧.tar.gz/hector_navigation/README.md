# hector_navigation
hector_navigation provides packages related to navigation of unmanned vehicles.
Originally developed for use in Urban Search and Rescue (USAR) environments.
