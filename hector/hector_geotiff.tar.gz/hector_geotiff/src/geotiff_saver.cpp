
#include <cstdio>
#include "ros/ros.h"
#include "ros/console.h"
#include "nav_msgs/GetMap.h"
#include "geometry_msgs/Quaternion.h"

#include <Eigen/Geometry>

#include <QtGui/QApplication>

#include <hector_map_tools/HectorMapTools.h>

#include <hector_geotiff/geotiff_writer.h>

using namespace std;

namespace hector_geotiff{

/**
 * @brief Map generation node.
 */
class MapGenerator
{
  public:
    MapGenerator(const std::string& mapname) : mapname_(mapname)
    {
      ros::NodeHandle n;
      ROS_INFO("In geotiff_saver.   Waiting for the map");
      map_sub_ = n.subscribe("map", 1, &MapGenerator::mapCallback, this);
    }

    void mapCallback(const nav_msgs::OccupancyGridConstPtr& map)
    {
      ros::Time start_time (ros::Time::now());
ROS_ERROR_STREAM("In geotiff_saver.  Before setMapFileName.. "  << mapname_.c_str());
      geotiff_writer.setMapFileName(mapname_);
      geotiff_writer.setupTransforms(*map);
      geotiff_writer.drawBackgroundCheckerboard();
      geotiff_writer.drawMap(*map);
      geotiff_writer.drawCoords();
ROS_ERROR("In geotiff_saver.   After   setMapFileName.");
      geotiff_writer.writeGeotiffImage();

      ros::Duration elapsed_time (ros::Time::now() - start_time);
      ROS_INFO("GeoTiff created in %f seconds", elapsed_time.toSec());
    }

    GeotiffWriter geotiff_writer;

    std::string mapname_;
    ros::Subscriber map_sub_;
};

}

#define USAGE "Usage: \n" \
              "  geotiff_saver -h\n"\
              "  geotiff_saver [-f <mapname>] [ROS remapping args]"

int main(int argc, char** argv)
{
  ros::init(argc, argv, "map_saver");
//在geotiff_writer.cpp中的前方给use_utc_time_suffix_设置为 false 停止使用当前的时间作为文件名字后缀
  std::string mapname = "good";

  for(int i=1; i<argc; i++)
  {
    if(!strcmp(argv[i], "-h"))
    {
      puts(USAGE);
      return 0;
    }
    else if(!strcmp(argv[i], "-f"))
    {
      if(++i < argc)
        mapname = argv[i];
      else
      {
        puts(USAGE);
        return 1;
      }
    }
    else
    {
      puts(USAGE);
      return 1;
    }
  }

ROS_INFO("setMapFileName.      HERE!!!!!!!!!!!!!");
//  GeotiffWriter geotiff_writer;
//  geotiff_writer.setMapName("test");

// set your mapname not here...although I think it's ok if I set my file's name here. But only when I set the name in the geotiff_writer.cpp could I change the file's name

  hector_geotiff::MapGenerator mg(mapname);

  ros::spin();

  return 0;
}

