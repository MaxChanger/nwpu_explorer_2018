#include "victim_service.h"
#include <iostream>
#include <ros/ros.h>
//#include <geometry_msgs/PoseStamped.h>
//#include <geometry_msgs/PoseWithCovariance.h>
#include "Object.h"
#include "ObjectModel.h"
#include <hector_worldmodel_msgs/Object.h>
#include <tf/transform_listener.h>
#include <string>

#include <tf/tf.h>
#include <std_msgs/String.h>
#include <std_msgs/Float32.h>
#include <hector_object_tracker/types.h>
#include <hector_worldmodel_msgs/SetObjectState.h>
#include <hector_worldmodel_msgs/SetObjectName.h>
#include <hector_worldmodel_msgs/AddObject.h>
#include <hector_worldmodel_msgs/GetObjectModel.h>
#include <sensor_msgs/CameraInfo.h>
#include <image_geometry/pinhole_camera_model.h>


VictimService::VictimService()
{
    ros::NodeHandle n;
    victimSub=n.subscribe("percept/pose",10,&VictimService::VictimInfoCallback,this);
    victimSer=n.advertiseService("get_victim_models",&VictimService::VictimServiceCallback,this);
    camera_left=new hector_object_tracker::ObjectModel("camera_left");
    camera_right=new hector_object_tracker::ObjectModel("camera_right");
}

VictimService::~VictimService(){}

void VictimService::VictimInfoCallback(const geometry_msgs::PoseStamped& pose)
{
    hector_worldmodel_msgs::Object ob;
    ob.header=pose.header;
    ob.pose.pose=pose.pose;
    ob.info.class_id="victim";
    std::stringstream ss;
    ss << pose.header.seq;
    ss >>ob.info.object_id;
    ob.info.name="victim";
    ob.info.support=1.0;
    ob.state.state=2;
    hector_object_tracker::Object *obj=new hector_object_tracker::Object(ob);
    if(ob.header.frame_id=="camera_left")
    {
        
        camera_left->add(hector_object_tracker::ObjectPtr(obj));
    }else
    {
        camera_right->add(hector_object_tracker::ObjectPtr(obj));
    }
}

bool VictimService::VictimServiceCallback(hector_worldmodel_msgs::GetObjectModel::Request& request, hector_worldmodel_msgs::GetObjectModel::Response& response)
{
    hector_object_tracker::ObjectModel merged("map");
    merged.mergeWith(*camera_left,tf,std::string("camera_left"));
    merged.mergeWith(*camera_right,tf,std::string("camera_right"));
    merged.getMessage(response.model);
}


int main(int argc,char** argv)
{
    ros::init(argc,argv,"victim_service");
    VictimService vc;
    ros::spin();
}