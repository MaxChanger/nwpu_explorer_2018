^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package hector_worldmodel_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.2 (2014-09-06)
------------------

0.3.1 (2014-03-30)
------------------

0.3.0 (2013-09-03)
------------------
* catkinized stack hector_worldmodel
* renamed package worldmodel_msgs to hector_worldmodel_msgs
