^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package hector_worldmodel_geotiff_plugins
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.2 (2014-09-06)
------------------
* write victims to file
* only draw largest qrcode into the geotiff
* qr codes may not have unique messages now
* Contributors: Alexander Stumpf, Dorothea Koert

0.3.1 (2014-03-30)
------------------
* Updated to new format 2014
* add missing "lib" prefix in library path
* Contributors: Alexander Stumpf, Thorsten Graber

0.3.0 (2013-09-03)
------------------
* catkinized stack hector_worldmodel
