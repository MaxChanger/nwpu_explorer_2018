# hector_worldmodel
hector_worldmodel collects and fuses information about objects in the world. Originally used by Team Hector Darmstadt to localize victims and QR codes in the Robocup Rescue scenario. hector_object_tracker is core package - pulls all information together into single worldmodel state. 
