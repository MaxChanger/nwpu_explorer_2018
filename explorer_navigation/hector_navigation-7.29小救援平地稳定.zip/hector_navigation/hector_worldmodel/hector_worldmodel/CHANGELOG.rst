^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package hector_worldmodel
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.2 (2014-09-06)
------------------

0.3.1 (2014-03-30)
------------------
* added missing <metapackage/> tag in package.xml
* Contributors: Johannes Meyer

0.3.0 (2013-09-03)
------------------
* catkinized stack hector_worldmodel
