#include "motion_detection.h"
/*#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/core/core.hpp>
*/
MotionDetection::MotionDetection()
{
  ros::NodeHandle n;
  ros::NodeHandle p_n("~"); //private nh

  img_prev_ptr_.reset();
  img_current_ptr_.reset();

  image_transport::ImageTransport it(n);
  image_transport::ImageTransport image_motion_it(p_n);
  image_transport::ImageTransport image_detected_it(p_n);

  p_n.param("sub_image_topic", sub_image_topic_, std::string("/usb_cam/image_raw"));

  image_sub_ = it.subscribeCamera(sub_image_topic_, 10, &MotionDetection::imageCallback, this);

  //    image_percept_pub_ = n.advertise<motion_detection::ImagePercept>("image_percept", 20);
  image_motion_pub_ = image_motion_it.advertiseCamera("image_motion", 10);
  image_detected_pub_ = image_detected_it.advertiseCamera("image_detected", 10);
}

MotionDetection::~MotionDetection() {}

void MotionDetection::imageCallback(const sensor_msgs::ImageConstPtr &img, const sensor_msgs::CameraInfoConstPtr &cam_info) //, const sensor_msgs::CameraInfoConstPtr& info)
{
  // get image

  //ROS_INFO("get a image");
  cv_bridge::CvImageConstPtr img_next_ptr(cv_bridge::toCvShare(img, sensor_msgs::image_encodings::MONO8));

  if (img_prev_ptr_)
  {
    // Calculates the per-element absolute difference between the prev&next images and do AND-operation
    // threshold image, low differences are ignored (ex. contrast change due to sunlight)
    cv::Mat diff1;
    cv::Mat diff2;
    cv::Mat img_motion;
    cv::absdiff(img_prev_ptr_->image, img_next_ptr->image, diff1);
    cv::absdiff(img_current_ptr_->image, img_next_ptr->image, diff2);
    cv::bitwise_and(diff1, diff2, img_motion); // Calculates the per-element bit-wise conjunction of two arrays or an array and a scalar.
    cv::threshold(img_motion, img_motion, motion_detect_threshold_, 255, CV_THRESH_BINARY);
    cv::Mat kernel_ero = getStructuringElement(cv::MORPH_RECT, cv::Size(5, 5)); // MORPH_RECT - a rectangular structuring element: Eij=1
    cv::erode(img_motion, img_motion, kernel_ero); // 图像腐蚀 Erodes an image by using a specific structuring element.

    unsigned long int number_of_changes = 0;
    int min_x = img_motion.cols, max_x = 0;
    int min_y = img_motion.rows, max_y = 0;
    // loop over image and detect changes
    for (int j = 0; j < img_motion.rows; j++)
    { // height
      for (int i = 0; i < img_motion.cols; i++)
      { // width
        // check if at pixel (j,i) intensity is equal to 255
        // this means that the pixel is different in the sequence
        // of images (prev_frame, current_frame, next_frame)

        // Calculates the numbers of difference and the min&max rowl&cols
        if (static_cast<int>(img_motion.at<uchar>(j, i)) == 255)
        {
          number_of_changes++;
          if (min_x > i)
            min_x = i;
          if (max_x < i)
            max_x = i;
          if (min_y > j)
            min_y = j;
          if (max_y < j)
            max_y = j;
        }
      }
    }

    cv::Mat img_detected;
    img_current_col_ptr_->image.copyTo(img_detected);

    double percept_size = std::max(std::abs(max_x - min_x), std::abs(max_y - min_y));
    double area = std::abs(max_x - min_x) * std::abs(max_y - min_y); // difference elements area
    double density = area > 0.0 ? number_of_changes / area : 0.0;    // difference elements number per area

    min_density = 0.0;
    // int dy = max_y - min_y, dx = max_x - min_x;
    // if (dy < 60)
    //   max_y += 60 - dy;
    // if (dx < 60)
    //   max_x += 60 - dx;

    ROS_INFO("number of changes = %lu ", number_of_changes);
    ROS_INFO("percept_size = %f  density = %f ", percept_size, density);
    // ROS_INFO("percept_size = %f  min_percept_size = %f  max_percept_size = %f ", percept_size, min_percept_size, max_percept_size);
    // ROS_INFO("density = %f  min_density = %f", density, min_density);
    ROS_INFO("max_x = %d  min_x = %d", max_x, min_x);
    ROS_INFO("max_y = %d  min_y = %d", max_y, min_y);

    //if (number_of_changes && max_percept_size > percept_size && percept_size > min_percept_size && density > min_density)
    if (number_of_changes>2000 && density > 0.0)
    {
      cv::rectangle(img_detected, cv::Rect(cv::Point(min_x, min_y), cv::Point(max_x, max_y)), CV_RGB(255, 255, 0), 5); //raws a simple, thick, or filled up-right rectangle.
    }

    // cv::imshow("view", img_current_ptr_->image);

    // 2015`9`19  cancel the code blocks as the info [bellow] is not a complete one if you want to use the motion image as the main evidence for victim
    /*
    sensor_msgs::CameraInfo::Ptr info;
    info.reset(new sensor_msgs::CameraInfo());
    //info->header = img->header;
    */

    if (image_motion_pub_.getNumSubscribers() > 0)
    {
      cv_bridge::CvImage cvImg;
      img_motion.copyTo(cvImg.image);
      cvImg.header = img->header;
      cvImg.encoding = sensor_msgs::image_encodings::MONO8;

      // ROS_ERROR_STREAM("motion=\n"<< info);

      image_motion_pub_.publish(cvImg.toImageMsg(), cam_info); // info -> cam_info
    }

    if (image_detected_pub_.getNumSubscribers() > 0)
    {
      cv_bridge::CvImage cvImg;
      img_detected.copyTo(cvImg.image);
      cvImg.header = img->header;
      cvImg.encoding = sensor_msgs::image_encodings::BGR8;
      image_detected_pub_.publish(cvImg.toImageMsg(), cam_info); // info -> cam_info
    }
  }

  // shift image buffers
  img_prev_ptr_ = img_current_ptr_;
  img_current_ptr_ = img_next_ptr;

  img_current_col_ptr_ = cv_bridge::toCvShare(img, sensor_msgs::image_encodings::BGR8);
}

int main(int argc, char **argv)
{

  ros::init(argc, argv, "motion_detection");
  MotionDetection md;
  ros::spin();

  return 0;
}
