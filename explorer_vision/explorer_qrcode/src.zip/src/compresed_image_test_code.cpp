#include <ros/ros.h>  
#include <opencv2/highgui/highgui.hpp>  
#include <cv_bridge/cv_bridge.h>  
  
  
#include <cv_bridge/cv_bridge.h>  
#include <cv.h>  
#include <highgui.h>  
#include "cxcore.hpp"  
#include <stdio.h>  
#include <stdlib.h>  
#include <string>  
#include <sstream>  
  
using namespace std;  
 long temptime=0;  
 char base_name[256];  
 string str;  
void imageCallback(const sensor_msgs::CompressedImageConstPtr& msg)  
{  
  try  
  {  
    cv::Mat image = cv::imdecode(cv::Mat(msg->data),1);//convert compressed image data to cv::Mat  
    //sprintf(base_name,"%4ld.jpg",temptime);  
    sprintf(base_name,"/home/wf/bagfiles/camera1/%4ld.jpg",temptime);  
    //str  
    //str="/home/wf/bagfiles/camera1/"+base_name;  
    cv::imwrite(base_name,image);  
    cv::imshow("view", image);  
    temptime++;  
    cv::waitKey(10);  
  }  
  catch (cv_bridge::Exception& e)  
  {  
    ROS_ERROR("Could not convert to image!");  
  }  
}  
  
int main(int argc, char **argv)  
{  
  ros::init(argc, argv, "image_listener");  
  ros::NodeHandle nh;  
  cv::namedWindow("view");  
  cv::startWindowThread();  
  ros::Subscriber sub = nh.subscribe("/camera1/image_raw/compressed", 1, imageCallback);  
  ros::spin();  
  cv::destroyWindow("view");  
} 
